const { validationResult } = require('express-validator');
const path = require('path');

const mainController = {
  index: (req, res) => {
    const results = req.method === 'POST' ? req.body : null;

    const errorsResult = validationResult(req);

    const errors = errorsResult.mapped();

    res.render('index', { results, errors });
  }
};

module.exports = mainController;
