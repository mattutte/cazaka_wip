const express = require('express');
const router = express.Router();
const mainController = require('../controllers/main');
const userValidations = require('../validations/user');

router.get('/', mainController.index);

// Resultados del formulario
router.post(
  '/',
  // Me agrega errores a la req que se pueden leer en otros middlewares
  userValidations, // Middleware de RUTA para validacion
  mainController.index
);

module.exports = router;
