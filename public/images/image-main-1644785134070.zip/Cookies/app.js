const cookieParser = require('cookie-parser');
const express = require('express');
const app = express();
const path = require('path');
const mainRouter = require('./routes/main');

app.use(express.static(path.join(__dirname, './public')));

app.use(express.urlencoded({ extended: false }));

app.use(cookieParser());

app.set('view engine', 'ejs');

app.use('/', mainRouter);

app.listen(3000, () => {
  console.log('Servidor corriendo http://localhost:3000');
});
