const { body } = require('express-validator');

const validateName = body('name').notEmpty().withMessage('Ingrese su nombre');

const validateEmail = body('email').notEmpty().withMessage('Ingrese su email');

const validateColor = body('color')
  .notEmpty()
  .withMessage('Seleccione un color');

const validateAge = body('age')
  .isInt()
  .withMessage('La edad debe ser un numero');

module.exports = [validateName, validateEmail, validateColor, validateAge];
